self.__precacheManifest = [
  {
    "revision": "d480a8c55d2d20eef2e0",
    "url": "/static/css/main.444ad052.chunk.css"
  },
  {
    "revision": "d480a8c55d2d20eef2e0",
    "url": "/static/js/main.58d82116.chunk.js"
  },
  {
    "revision": "89cbdf1418fb73c99b71",
    "url": "/static/js/runtime~main.9667c5b8.js"
  },
  {
    "revision": "50cf6d7496b25d143102",
    "url": "/static/js/2.9a4fabd2.chunk.js"
  },
  {
    "revision": "94d78f9f36a1be11b0ef",
    "url": "/static/js/3.2f2d2a6e.chunk.js"
  },
  {
    "revision": "e63562614cbdc491e4d374f97c513b82",
    "url": "/static/media/font.e6356261.woff"
  },
  {
    "revision": "89b89c287754305c5c78d8befa7a5bed",
    "url": "/index.html"
  }
];